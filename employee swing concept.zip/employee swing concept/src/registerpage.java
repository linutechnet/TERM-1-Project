import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class registerpage extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					registerpage frame = new registerpage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public registerpage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblRegisterPage = new JLabel("REGISTER PAGE");
		lblRegisterPage.setFont(new Font("Arial", Font.BOLD, 12));
		lblRegisterPage.setBounds(140, 11, 150, 27);
		contentPane.add(lblRegisterPage);
		
		JLabel lblEmail = new JLabel("EMAIL");
		lblEmail.setFont(new Font("Century", Font.BOLD, 12));
		lblEmail.setBounds(41, 59, 72, 15);
		contentPane.add(lblEmail);
		
		JLabel lblPassword = new JLabel("PASSWORD");
		lblPassword.setFont(new Font("Century", Font.BOLD, 12));
		lblPassword.setBounds(41, 97, 72, 15);
		contentPane.add(lblPassword);
		
		JLabel lblAge = new JLabel("AGE");
		lblAge.setFont(new Font("Century", Font.BOLD, 12));
		lblAge.setBounds(41, 139, 72, 15);
		contentPane.add(lblAge);
		
		JLabel lblMobileNo = new JLabel("MOBILE NO");
		lblMobileNo.setFont(new Font("Century", Font.BOLD, 12));
		lblMobileNo.setBounds(41, 182, 72, 15);
		contentPane.add(lblMobileNo);
		
		textField = new JTextField();
		textField.setBounds(175, 57, 177, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(175, 95, 177, 20);
		contentPane.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(175, 137, 177, 20);
		contentPane.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(175, 180, 177, 20);
		contentPane.add(textField_3);
		
		JButton btnSubmit = new JButton("SUBMIT");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) 
			{
				
				 
				 try
				 {
					
					 String email=textField.getText();
					 String pass=textField_1.getText();
					 String age=textField_2.getText();
					 String mobile=textField_3.getText();
					 String str="insert into register values('"+email+"','"+pass+"','"+age+"','"+mobile+"')";
					 
					 Class.forName("org.h2.Driver");
					Connection conn=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa","");
					Statement stm=conn.createStatement();
					stm.executeUpdate(str);
					JOptionPane.showMessageDialog(btnSubmit,"inserted...");
					
					
				 }
				 catch(Exception r)
				 {
					 System.out.println(r);
				 }
				
			}
		});
		btnSubmit.setFont(new Font("Algerian", Font.PLAIN, 12));
		btnSubmit.setBounds(67, 227, 89, 23);
		contentPane.add(btnSubmit);
		
		JButton btnReset = new JButton("RESET");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				if(e.getSource()==btnReset)
				{
					textField.setText("");
					textField_1.setText("");
					textField_2.setText("");
					textField_3.setText("");
				}
			}
		});
		btnReset.setFont(new Font("Algerian", Font.PLAIN, 12));
		btnReset.setBounds(220, 227, 89, 23);
		contentPane.add(btnReset);
	}

}
