import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class loginhomepage extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					loginhomepage frame = new loginhomepage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public loginhomepage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblLoginhomepage = new JLabel("LOGINHOMEPAGE");
		lblLoginhomepage.setFont(new Font("Arial", Font.BOLD, 12));
		lblLoginhomepage.setBounds(186, 27, 122, 25);
		contentPane.add(lblLoginhomepage);
		
		JButton btnUserLogin = new JButton("USER LOGIN");
		btnUserLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				userlogin user=new userlogin();
				user.setVisible(true);
			}
		});
		btnUserLogin.setFont(new Font("Algerian", Font.PLAIN, 12));
		btnUserLogin.setBounds(239, 92, 145, 25);
		contentPane.add(btnUserLogin);
		
		JButton btnNewButton = new JButton("ADMINLOGIN");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				adminloginpage admin=new adminloginpage();
				admin.setVisible(true);
				
			}
		});
		btnNewButton.setFont(new Font("Algerian", Font.PLAIN, 12));
		btnNewButton.setBounds(239, 168, 145, 25);
		contentPane.add(btnNewButton);
	}

}
