import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;

public class deletepage extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					deletepage frame = new deletepage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public deletepage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblDeletePage = new JLabel("DELETE PAGE");
		lblDeletePage.setFont(new Font("Arial", Font.BOLD, 12));
		lblDeletePage.setBounds(166, 29, 149, 24);
		contentPane.add(lblDeletePage);
		
		JLabel lblEmail = new JLabel("EMAIL");
		lblEmail.setFont(new Font("Century", Font.BOLD, 12));
		lblEmail.setBounds(65, 92, 46, 14);
		contentPane.add(lblEmail);
		
		textField = new JTextField();
		textField.setBounds(214, 90, 170, 24);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnDelete = new JButton("DELETE");
		btnDelete.setFont(new Font("Algerian", Font.PLAIN, 12));
		btnDelete.setBounds(85, 188, 89, 23);
		contentPane.add(btnDelete);
	}

}
