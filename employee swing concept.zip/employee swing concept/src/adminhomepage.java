import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class adminhomepage extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					adminhomepage frame = new adminhomepage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public adminhomepage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblAdminHomepage = new JLabel("ADMIN HOMEPAGE");
		lblAdminHomepage.setFont(new Font("Arial", Font.BOLD, 12));
		lblAdminHomepage.setBounds(165, 21, 137, 22);
		contentPane.add(lblAdminHomepage);
		
		JButton btnViewAllUser = new JButton("VIEW ALL USER DETAILS");
		btnViewAllUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnViewAllUser)
				{
					new viewuserdetails().setVisible(true);
				}
			}
		});
		btnViewAllUser.setFont(new Font("Algerian", Font.PLAIN, 12));
		btnViewAllUser.setBounds(89, 70, 167, 23);
		contentPane.add(btnViewAllUser);
		
		JButton btnNewUserDetails = new JButton("NEW USER DETAILS");
		btnNewUserDetails.setFont(new Font("Algerian", Font.PLAIN, 12));
		btnNewUserDetails.setBounds(89, 119, 167, 23);
		contentPane.add(btnNewUserDetails);
		
		JButton btnAddEmployeeDetails = new JButton("ADD EMPLOYEE DETAILS");
		btnAddEmployeeDetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			   registerpage register=new registerpage();
			   register.setVisible(true);
			   
			}
			
		});
		btnAddEmployeeDetails.setFont(new Font("Algerian", Font.PLAIN, 12));
		btnAddEmployeeDetails.setBounds(89, 169, 167, 23);
		contentPane.add(btnAddEmployeeDetails);
		
		JButton btnDeteleEmployeeDetails = new JButton("DETELE EMPLOYEE DETAILS");
		btnDeteleEmployeeDetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				deletepage delete=new deletepage();
				delete.setVisible(true);
				
			}
		});
		btnDeteleEmployeeDetails.setFont(new Font("Algerian", Font.PLAIN, 12));
		btnDeteleEmployeeDetails.setBounds(89, 227, 167, 23);
		contentPane.add(btnDeteleEmployeeDetails);
	}

}
