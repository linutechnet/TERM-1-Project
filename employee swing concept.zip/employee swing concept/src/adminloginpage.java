import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverAction;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class adminloginpage extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					adminloginpage frame = new adminloginpage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public adminloginpage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblAdminloginpage = new JLabel("ADMINLOGINPAGE");
		lblAdminloginpage.setFont(new Font("Arial", Font.BOLD, 12));
		lblAdminloginpage.setBounds(171, 11, 138, 23);
		contentPane.add(lblAdminloginpage);
		
		JLabel lblAdminName = new JLabel("ADMIN NAME");
		lblAdminName.setFont(new Font("Century", Font.BOLD, 12));
		lblAdminName.setBounds(72, 96, 113, 15);
		contentPane.add(lblAdminName);
		
		textField = new JTextField();
		textField.setBounds(256, 94, 138, 23);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblAdminPassword = new JLabel("ADMIN PASSWORD");
		lblAdminPassword.setFont(new Font("Century", Font.BOLD, 12));
		lblAdminPassword.setBounds(72, 149, 152, 15);
		contentPane.add(lblAdminPassword);
		
		textField_1 = new JTextField();
		textField_1.setBounds(256, 147, 138, 23);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JButton btnLogin = new JButton("LOGIN");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					String n=textField.getText();
					String p=textField_1.getText();
					String str="select * from adminlogin where adminname='"+n+"' and adminpass='"+p+"'";
					
					 Class.forName("org.h2.Driver");
						Connection conn=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa","");
						Statement stm=conn.createStatement();
						ResultSet rs=stm.executeQuery(str);
						rs.next();
						String n1=rs.getString(1);
						String p1=rs.getString(2);
						if(n.equals(n1)&&p.equals(p1))
						{
							new adminhomepage().setVisible(true);

						}	
						
						
						
					 }
					 catch(Exception r)
					 {
						 System.out.println("login failed....");
					 }
				
				}
				
			}
		);
		btnLogin.setFont(new Font("Algerian", Font.PLAIN, 12));
		btnLogin.setBounds(70, 227, 89, 23);
		contentPane.add(btnLogin);
		
		JButton btnReset = new JButton("RESET");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
			 if(e.getSource()==btnReset)	
			
			 {textField.setText("");
			 textField_1.setText("");
				 }
			 }
			
		});
		btnReset.setFont(new Font("Algerian", Font.PLAIN, 12));
		btnReset.setBounds(257, 227, 89, 23);
		contentPane.add(btnReset);
	}

}
