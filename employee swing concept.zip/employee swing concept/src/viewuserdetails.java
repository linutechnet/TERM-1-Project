import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class viewuserdetails extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					viewuserdetails frame = new viewuserdetails();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public viewuserdetails() {
		
		table = new JTable();
		getContentPane().add(table, BorderLayout.CENTER);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10,95,393,155);
		contentPane.add(scrollPane);
		
		table=new JTable();
		scrollPane.setViewportView(table);
		
		JLabel lblUsername = new JLabel("EMAIL");
		lblUsername.setFont(new Font("Arial", Font.BOLD, 12));
		lblUsername.setBounds(45, 31, 94, 15);
		contentPane.add(lblUsername);
		
		textField = new JTextField();
		textField.setBounds(183, 29, 140, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnDeleteDetails = new JButton("DELETE DETAILS");
		btnDeleteDetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				 try
				 {
					
					 String email=textField.getText();
					 String str1="delete from register where email='"+email+"'";
					 
					 
					 Class.forName("org.h2.Driver");
					Connection conn=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa","");
					Statement stm=conn.createStatement();
					stm.executeUpdate(str1);
					JOptionPane.showMessageDialog(btnDeleteDetails,"user deleted...");
					
					
				 }
				 catch(Exception r)
				 {
					 System.out.println(r);
				 }
				
				
			}
		});
		btnDeleteDetails.setFont(new Font("Century", Font.PLAIN, 12));
		btnDeleteDetails.setBounds(101, 61, 140, 20);
		contentPane.add(btnDeleteDetails);
		
		JButton btnViewDetails = new JButton("VIEW DETAILS");
		btnViewDetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					String email=textField.getText();
					
					String str="select * from register where email='"+email+"' ";
					
					 Class.forName("org.h2.Driver");
						Connection conn=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa","");
						Statement stm=conn.createStatement();
						ResultSet rs=stm.executeQuery(str);
						table.setModel(DbUtils.resultSetToTableModel(rs));
			    }
				catch(Exception r)
				{
					System.out.println(r);
				}
			
			}
		});
		btnViewDetails.setFont(new Font("Century", Font.PLAIN, 12));
		btnViewDetails.setBounds(285, 60, 118, 24);
		contentPane.add(btnViewDetails);
	}
}
